# Agenda
Exemplo em Java com uma classe Pessoa usada pela classe Agenda.

## Descrição do exercício
### Lab 2: finalizar a implementação da Agenda de Contatos

* Você deve inserir pelo menos dois outros atributos na classe Pessoa.
* Você deve implementar, na classe Agenda, os métodos "adicionarContato", "buscarContato", "atualizarContato", "removerContato", "listarContatos". Esses métodos deverão ser chamados no método "main" (dentro das respectivas opções do switch-case), que é estático, por isso, avalie se esses novos métodos também deverão ser estáticos.
* Algumas variáveis também passarão a ser estáticas (variáveis de classe) para serem acessadas pelos novos métodos.
* Escrever os testes automatizados para os métodos da classe Pessoa.
