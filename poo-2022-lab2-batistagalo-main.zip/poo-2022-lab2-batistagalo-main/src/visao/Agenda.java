package visao;

import java.util.ArrayList;
import java.util.Scanner;

import modelo.Pessoa;

public class Agenda {

	public static void main(String[] args) {
		ArrayList<Pessoa> meusContatos = new ArrayList<Pessoa>();
		Pessoa contato;

		Scanner entrada = new Scanner(System.in);
		int opcao = -1;

		while (opcao !=0) {
			System.out.println("\n");
			System.out.println("Digite uma opção:");
			System.out.println("1- Adicionar contato");
			System.out.println("2- Buscar contato");
			System.out.println("3- Atualizar contato");
			System.out.println("4- Remover contato");
			System.out.println("5- Listar todos os contatos");
			System.out.println("0- Sair");
			System.out.println("----------------");

			opcao = Integer.parseInt(entrada.nextLine());

			switch (opcao) {
				case 1: {
					System.out.println("Digite o nome:");
					contato = new Pessoa (entrada.nextLine());

					System.out.println("Digite o telefone:");
					contato.setTelefone(entrada.nextLine());

					System.out.println("Digite o email:");
					contato.setEmail(entrada.nextLine());

					System.out.println("----------------");
					System.out.println("Contato Cadastrado com Sucesso");
					System.out.println(contato.toString());

					meusContatos.add(contato);
					break;
				}
				case 2: {
					//TODO
					break;
				}
				case 3: {
					//TODO
					break;
				}
				case 4: {
					//TODO
					break;
				}
				case 5: {
					//TODO
					break;
				}
				case 0: {
					System.out.println("Obrigado por usar a Agenda.");
					System.exit(opcao);
				}
				default:{
					System.out.println("Opção " + opcao + " inválida.");
					break;
				}
			}
		}
		entrada.close();
	}
}