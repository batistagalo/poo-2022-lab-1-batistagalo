package model;

import static org.junit.Assert.*;

import org.junit.Test;

import modelo.Pessoa;

public class TestPessoa {

	@Test
	public void criaPessoa() {
		Pessoa umaPessoa = new Pessoa("Ada Lovelace");
		assertEquals("Ada Lovelace", umaPessoa.getNome());
	}
	
	

}
