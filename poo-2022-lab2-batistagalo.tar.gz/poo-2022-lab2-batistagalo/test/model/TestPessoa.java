package model;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.Before;
import org.junit.Test;

import modelo.Pessoa;

public class TestPessoa {

	private Pessoa contato;
	
	@Before
	public void criaPessoa() {
		Pessoa contato = new Pessoa("Marina Galo");
		contato.setNome("Marina Galo");
		contato.setEmail("batistagalo@gmail.com");
		contato.setTelefone("(11)94565-0026");	
		contato.setTwitter("paracomissomar");
		contato.setInsta("paracomissomar");
	}
	
	@Test
	private void verificaNome() {
		assertEquals("Marina Galo", contato.getNome());	
	}
	
	@Test 
	private void verificaTelefone() {
		assertEquals("(11)94565-0026", contato.getTelefone());
	}

	@Test
	private void verificaEmail() {
		assertEquals("batistagalo@gmail.com", contato.getEmail());
	}	

	@Test
	private void verificaTwitter() {
		assertEquals("paracomissomar", contato.getTwitter());
	}	
	
	@Test
	private void verificaInsta() {
		assertEquals("paracomissomar", contato.getInsta());
	}	
}