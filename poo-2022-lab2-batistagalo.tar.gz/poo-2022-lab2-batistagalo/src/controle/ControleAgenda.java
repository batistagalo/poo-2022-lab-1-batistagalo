package controle;
import java.util.ArrayList;
import modelo.Pessoa;

public class ControleAgenda{ 
	private ArrayList<Pessoa> meusContatos;
	
	public ControleAgenda() {
		meusContatos = new ArrayList<Pessoa>();
	}
	
	public Pessoa atualizarContato (String nome, String telefone, String email, String twitter, String instagram) {
		
		
		
		
		return contato;
	}
}