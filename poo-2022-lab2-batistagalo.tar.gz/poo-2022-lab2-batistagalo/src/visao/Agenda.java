package visao;

import java.util.ArrayList;


import java.util.Scanner;

import modelo.Pessoa;

public class Agenda {
	private static ArrayList<Pessoa> meusContatos = new ArrayList<Pessoa>();
	private static Scanner entrada = new Scanner(System.in);
	public static Pessoa marina;
	
	public static void main(String[] args) {
		// Variável para o while
		int opcao = -1;
		
		// Instanciar os objetos
		meusContatos.add(new Pessoa("Marina Galo", "(11)94565-0026", 
				"batistagalo@gmail.com", "paracomissomar", "paracomissomar"));
		
		while (opcao !=0) {
			System.out.println("----------------");
			System.out.println("1- Adicionar contato");
			System.out.println("2- Buscar contato");
			System.out.println("3- Atualizar contato");
			System.out.println("4- Remover contato");
			System.out.println("5- Listar todos os contatos");
			System.out.println("0- Sair");
			System.out.println("----------------");

			System.out.print("Digite uma opção:");
			opcao = Integer.parseInt(entrada.nextLine());

			switch (opcao) {
				case 1: {
					adicionarContato();
					break;
				}
				case 2: {
					buscarContato();
					break;
				}
				case 3: {
					atualizarContato();
					break;
				}
				case 4: {
					removerContato();
					break;
				}
				case 5: {
					listarContatos();
					break;
				}
				case 0: {
					System.out.println("Obrigado por usar a Agenda.");
					System.exit(opcao);
				}
				default:{
					System.out.println("Opção " + opcao + " inválida.");
					break;
				}
			}
		}
		entrada.close();
	}
	private static void adicionarContato() {
		System.out.print("Digite o nome:");
		Pessoa contato = new Pessoa (entrada.nextLine());

		meusContatos.add(dadosDoContato(contato));
		System.out.println("Contato cadastrado com sucesso!");
	}
	private static Pessoa dadosDoContato(Pessoa contato) {
		System.out.print("Digite o telefone: ");
		contato.setTelefone(entrada.nextLine());

		System.out.print("Digite o email: ");
		contato.setEmail(entrada.nextLine());
		
		System.out.print("Digite o twitter: ");
		contato.setTwitter(entrada.nextLine());

		System.out.print("Digite o instagram: ");
		contato.setInsta(entrada.nextLine());
		System.out.println("----------------");
		
		System.out.println(contato.toString());
		return contato;
	}
	
	public static void atualizarContato() {
		
		System.out.print("Digite o nome:");
		Pessoa contato = buscarPorNome(entrada.nextLine());
		
		if(contato == null)
			System.out.println("Contato inexistente!");
		else {
			System.out.println("Contato encontrado!");
		}
		System.out.print("Digite o Nome:");
		contato.setNome(entrada.nextLine());
		dadosDoContato(contato);
		System.out.println("Dados alterados com sucesso!");
	}
		
	public static void buscarContato() {
		System.out.print("Digite o nome:");
		Pessoa contato = buscarPorNome(entrada.nextLine());
		
		if(contato == null) {
			System.out.println("Contato inexistente!");
		}else {
			System.out.println(contato);
		}
	}
	
	public static Pessoa buscarPorNome (String umNome) {
		
		for(Pessoa umaPessoa: meusContatos) {
			String nomePesquisado = umaPessoa.getNome();
			
			if(nomePesquisado.equalsIgnoreCase(umNome)) {
				return umaPessoa;
			}
		}
		return null;
	}
	
	public static void removerContato() {
		System.out.print("Digite o nome:");
		Pessoa contato = buscarPorNome(entrada.nextLine());
		
		if(contato == null) {
			System.out.println("Contato inexistente!");
		}else {
			meusContatos.remove(contato);
			System.out.println("Contato removido com sucesso!");
		}
	}
	
	public static void listarContatos() {
		for (Pessoa umaPessoa: meusContatos) {
			System.out.println(umaPessoa);
		}
	}
}